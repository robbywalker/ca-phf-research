#pragma once

#include <stdlib.h>
#include <stdio.h>

#include "symbol.h"
#include "util/util.h"

namespace arrays {
	class int_SymbolGenerator;

	class int_Symbol {
		int value;

	public:
		int_Symbol() {
			value = 0;
		}

		int_Symbol(int val) {
			value = val;
		}

		void print() const {
			printf("%d", value);
		}

		friend bool operator==(const int_Symbol & x, const int_Symbol & y) {
			return x.value == y.value;
		}

		friend int_SymbolGenerator;
	};

	class int_SymbolGenerator : public SymbolGenerator<int_Symbol> {
		int count;
	public:
		int_SymbolGenerator(int count) {
			this->count = count;
		}

		virtual int getCount() const {
			return count;
		}

		virtual int_Symbol generate(int val) const {
			return int_Symbol(val);
		}

		virtual int_Symbol defaultValue() const {
			return int_Symbol();
		}

		virtual int_Symbol randomValue() const {
			return int_Symbol( util::random( count ) );
		}
	};
};