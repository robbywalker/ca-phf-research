#pragma once

namespace util {

	int random(int max);
	int weightedRandom( int * weights, int total );

};