#include "util.h"
#include <stdlib.h>

namespace util {

	// return a random number between 0 and max - not including max
	// does this with equal probability 
	int random( int max ) {
		int div = (int) ((double)RAND_MAX) / max;

		int newMax = div * max;

		int v = 0;
		do {
			v = rand();
		} while ( v >= newMax );

		return ( v / div );
	}

	// weighted random number
	int weightedRandom( int * weights, int total ) {
		int k = random( total );

		int i = 0;
		while ( k >= weights[i] ) {
			k -= weights[i];
			i++;
		}

		return i;
	}
};