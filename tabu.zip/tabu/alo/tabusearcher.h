#pragma once

#include "../tabu/search.h"
#include "../arrays/symbol.h"
#include "../util/util.h"

namespace alo {
	//typedef std::pair<int,int> _COORD;

	template <class SYM, class RowChecker>
	class alo_tabuSearcher : public tabu::TabuSearcher< tabuStatus<RowChecker,SYM>, arrays::Array<SYM> >
	{
		int * counts;
		int rows;

		int test;
		//std::list<COORD> tabu;
	public:
		alo_tabuSearcher( arrays::SymbolGenerator<SYM> * sg, int rows, int cols, int strength) : 
		  tabu::TabuSearcher< tabuStatus<RowChecker,SYM>, arrays::Array<SYM> >( tabuStatus<RowChecker,SYM>( arrays::Array<SYM>( sg, rows, cols, true ), strength ) )
		{
			counts = new int[cols];
			this->rows = rows;
			test = 0;
		}

		~alo_tabuSearcher() {
			delete[] counts;
		}

		// returns false if no moves could be generated
		virtual bool generateMovesAndPerformBest() {
			int total = current.countBadPerColumn( counts );
			int colToChange = util::weightedRandom(counts, total);

			if ( ++test == 10000000 ) return false;

			int bestDelta = 0;
			int bestI = -1;
			int bestR = -1;

			arrays::SymbolGenerator<SYM> * sGen = current.getSymbolGenerator();
			int count = sGen->getCount();			

			for ( int r = 0; r < rows; r++ ) {
				SYM curS = current.getArrayValue( r, colToChange );

				for ( int i = 0; i < count; i++ ) {
					SYM value = sGen->generate( i );
					if ( ! (value == curS) ) {
						int delta = current.calculateEffectOfChange( r, colToChange, value );

						if ( bestI == -1 || delta < bestDelta ) {
							bestI = i;
							bestR = r;
							bestDelta = delta;
						} else if ( delta == bestDelta && (util::random(3) == 1)) {
							bestI = i;
							bestR = r;
							bestDelta = delta;
						}
					}
				}
			}

			SYM value = sGen->generate( bestI );
			current.change( bestR, colToChange, value );			

			// we may wish to consider "column ror" as a sort of larger move - where every entry in the
			// column is changed (rotated right) by a specific value

			return true;
		}
	};

};