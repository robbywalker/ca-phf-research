#pragma once

// a tuple-map is an array indexed by tuples - it takes some work to do this efficiently

#include "../arrays/tuple.h"

namespace alo {
	template <class T>
	union _tm_elem {
		_tm_elem ** arr;
		T * data;
	};

	template <class T>
	class tupleMap {
		int t, k;
		_tm_elem<T> * data;
		int * refs;

		// recursively initialize the data store
		_tm_elem<T> * init( int strength, int cols ) {
			_tm_elem<T> * ret;

			if ( strength == 0 ) {
				// stop when we reach the last index
				ret = new _tm_elem<T>();
				ret->data = new T();

			} else {
				int count = cols - strength + 1;
				ret = new _tm_elem<T>();
				ret->arr = new _tm_elem<T>*[ cols - strength + 1 ];
				for ( int i = 0; i < count; i++ ) {
					ret->arr[i] = init( strength - 1, cols - i - 1 );
				}
			}
			return ret;
		}

		_tm_elem<T> * get( const arrays::tuple &t ) const {
			int s = t.strength();
			int last = -1;
			_tm_elem<T> * cur = data;
			for ( int i = 0; i < s; i++ ) {
                cur = cur->arr[ t.get(i) - last - 1 ];
				last = t.get(i);
			}
			return cur;
		}

	public:
		tupleMap( int strength, int cols ) {
			data = init( strength, cols );		
			t = strength;
			k = cols;
			refs = new int;
			*refs = 1;
		}		

		tupleMap( tupleMap & copy ) { // no copying!
			data = copy.data;
			t = copy.t;
			k = copy.k;
			refs = copy.refs;
			*refs = *refs + 1;
		}

		~tupleMap() {
			*refs = *refs - 1;
			if ( *refs == 0 ) {
				delete refs;
				// delete the elements
				for ( int i = t; i > 0; i-- ) {
					arrays::tuple tp(i, k - ( t - i ));

					do {
						_tm_elem<T> * e = get( tp );
						if ( i == t ) {
							delete e->data;
						} else {
							delete[] e->arr;
						}
						delete e;
					} while ( ++tp );
				}

				delete[] data->arr;
				delete data;
			}
		}

		T* & operator[]( arrays::tuple t ) {
            return get(t)->data;		
		}

		const T* & operator[]( arrays::tuple t ) const {
            return get(t)->data;		
		}
	};
}