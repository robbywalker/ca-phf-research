#pragma once

#include "../arrays/array.h"
#include "../arrays/tuple.h"
#include "../arrays/symbol.h"
#include "tupleMap.h"
#include <set>

namespace alo {
	typedef std::set<int> rowset;

	template <class RowChecker, class Symbol>
	class tabuStatus {
		int strength;
		arrays::Array<Symbol> arr;
		tupleMap<rowset> goods;
		std::set<arrays::tuple> bads;
	public:
		tabuStatus() {
		}

		tabuStatus( arrays::Array<Symbol> & _arr, int _strength ) : 
		  arr(_arr), 
		  goods(_strength, arr.getWidth())  
		{
			printf("Construction tabu status!\n");

			strength = _strength;

			int v = arr.getSymbolCount();
			int k = arr.getWidth();
			int N = arr.getHeight();

			std::vector<Symbol> slice(strength);
			arrays::tuple t(strength, k);

			int i;
			bool found;

			long inc = 0;
			do {
				// FIRST CHECK THE CURRENT T-TUPLE
				found = false;

				for ( i = 0; i < N; i++ ) {
					arr.sliceInto(i, t, slice);
					if ( RowChecker::good( slice ) ) {
						found = true;
						goods[ t ]->insert( i );
					}
				}
                
				if ( ! found ) {
					bads.insert( t );					
				}

				inc++;
				if ( (inc % 10000) == 0 ) {
					printf("at inc %ld with %ld bads\n", inc, (long) bads.size() );
				}

				// NOW, INCREMENT THE CURRENT T-TUPLE
			} while ( ++t );

			printf("Finished construction of tabu status!\n");
		}

		int getScore() {
			return (int) bads.size();
		}

		void getResultInto(arrays::Array<Symbol> & s) {
			arr.copyInto( s );
		}

		Symbol getArrayValue( int i, int j ) const {
			return arr.get(i, j);
		}

		arrays::SymbolGenerator<Symbol> * getSymbolGenerator() {
			return arr.gen;
		}

		void print() const {
			printf("\nBAD TUPLES: \n");
			std::set<arrays::tuple>::const_iterator it = bads.begin();
			for ( ; it != bads.end(); it++ ) {
				it->print();
				printf("\n");
			}

			printf("\nTUPLE MAP: \n");
			arrays::tuple t(strength, arr.getWidth());

			do { 
				const rowset * r = goods[ t ];

				t.print();
				printf(" ==> ");

				if ( r->empty() ) {
					printf("XX");
				} else {
					rowset::const_iterator rsIt = r->begin();
					while ( true ) {
						printf("[%d]", *rsIt);

						if ( ++rsIt != r->end() ) {
							printf(" -> ");
						} else {
							break;
						}
					}
				}
				printf("\n");

			} while (++t);
			printf("\n");
		}

		int countBadPerColumn( int * counts ) {
			int total = 0;
			for ( int i = 0; i < arr.getWidth(); i++ ) {
				counts[i] = 0;
			}

			std::set<arrays::tuple>::const_iterator it = bads.begin();
			for ( ; it != bads.end(); it++ ) {
				int st = it->strength();

				for ( i = 0; i < st; i++ ) {
					counts[ it->get( i ) ]++;
					total++;
				}
			}

			return total;
		}

		// TODO: Test this
		int calculateEffectOfChange( int row, int col, Symbol newValue ) {
			arrays::tuple iterator( strength - 1, arr.getWidth() - 1 );
			arrays::tuple real( strength, arr.getWidth() );

			std::vector<Symbol> slice(strength);

			int delta = 0;

			do {
				real.initViaUpgrade( iterator, col );

				int sz = (int) goods[ real ]->size();
				if ( sz == 0 ) {
					// things can get better if this tuple was previously bad
					arr.sliceInto(row,real,slice);
					slice[ real.indexOf( col ) ] = newValue;

					if ( RowChecker::good( slice ) )
						delta--;

				} else if ( sz == 1 ) {
					// things can get worse if this tuple was previously good, but not covered
					arr.sliceInto(row,real,slice);

					if ( RowChecker::good( slice ) ) {
						slice[ real.indexOf( col ) ] = newValue;

						if ( ! RowChecker::good( slice ) )
							delta++;
					}
				}

			} while ( ++iterator );

			return delta;
		}		

		// TODO: Test this
		int change( int row, int col, Symbol newValue ) {
			arr.set( row, col, newValue );

			arrays::tuple iterator( strength - 1, arr.getWidth() - 1 );
			arrays::tuple real( strength, arr.getWidth() );

			std::vector<Symbol> slice(strength);

			int delta = 0;

			do {
				real.initViaUpgrade( iterator, col );
				arr.sliceInto(row,real,slice);

				bool wasBad = ( goods[ real ]->size() == 0 );
				
				if ( RowChecker::good( slice ) ) {
					goods[ real ]->insert( row );
					if ( wasBad ) {
						bads.erase( real );
					}
				} else {
					goods[ real ]->erase( row );
					if ( !wasBad && goods[ real ]->size() == 0 ) {
						bads.insert( real );
					}
				}

			} while ( ++iterator );

			return delta;
		}	
	};
};