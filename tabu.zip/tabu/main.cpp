#include "arrays/array.h"
#include "arrays/intsymbol.h"
#include "arrays/tuple.h"

#include "alo/checkArray.h"
#include "alo/tabuStatus.h"
#include "alo/tabusearcher.h"

#include "phf/check.h"
#include <stdlib.h>
#include <time.h>

typedef arrays::int_Symbol SYM;
typedef phf::phf_Check<SYM> ROW_CHECK;

void testArrayGen(void) {
	srand( (unsigned)time( NULL ) );

	arrays::Array<SYM> x(&arrays::int_SymbolGenerator(4),6,10,true);
	x.print();

	printf("\n\n");

	alo::tabuStatus<ROW_CHECK,SYM> status(x, 3);
	status.print();

	int counts[10];
	int total = status.countBadPerColumn(counts);
	printf("\n[");
	for ( int i = 0; i < 10; i++ ) {
		printf("%d ", counts[i]);
	}
	printf("] = %d\n", total);


}

void doTabu(int rows, int cols, int syms, int strength) {
	srand( (unsigned)time( NULL ) );
	
	alo::alo_tabuSearcher<SYM,ROW_CHECK> ts(&arrays::int_SymbolGenerator(syms),rows,cols,strength);
	ts.search();
}

void main(int argc, char* argv[]) {
	//testArrayGen();
	doTabu(atoi(argv[1]), atoi(argv[2]), atoi(argv[3]), atoi(argv[4]));
}