#pragma once

namespace tabu {

	template <class State, class Result>
	class TabuSearcher {
	protected:
		Result best;
		int bestScore;

		State current;
	public:
		TabuSearcher(State start) :
			current( start )
		{
			start.getResultInto(best);
			bestScore = start.getScore();
		}

		const Result& getBest() {
			return best;
		}

		int getBestScore() {
			return bestScore;
		}

		// RETURNS:
		//	  0 - nothing important happened
		//	  1 - a new best score was found
		//	  -1 - there were no available moves
		int iterate() {
			if ( !this->generateMovesAndPerformBest() ) {
				return -1;
			}

			if ( current.getScore() < bestScore ) {
				bestScore = current.getScore();
				current.getResultInto(best);
				return 1;
			}

			return 0;
		}

		virtual bool generateMovesAndPerformBest() = 0;

		void search() {
			long its = 0;
			int res;
			while ( bestScore > 0 ) {
				if ( its == 0 ) {
					printf("performing first iteration\n");
				}
				res = iterate();
				if ( its == 0 ) {
					printf("done performing first iteration\n");
				}
				its++;
				if ( res == 1 ) {
					printf("**** FOUND NEW BEST SCORE = %d (at iteration %ld)!\n", bestScore, its);
					best.print();

				} else if ( res == -1 ) {
					printf("!!!! STUCK! (at iteration %ld)\n", its);
					break;
				} else if ( (its % 1000) == 0 ) {
					printf("-- ITERATION %ld CURRENT SCORE %d\n", its, current.getScore());
				}
			}

			if ( bestScore == 0 )
				printf("\n********** FOUND SCORE = 0 (at iteration %ld)!\n", its);

			best.print();
		}
	};
};