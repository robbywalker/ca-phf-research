#pragma once

#include <vector>

namespace phf {

	template <class Symbol>
	class phf_Check {
	public:
		static void init() {
		}

		static bool good( const std::vector<Symbol> slice ) {
			int size = (int) slice.size();
			for ( int i = 0; i < (size - 1); i++ ) {
				for ( int j = i+1; j < size; j++ ) {
					if ( slice[i] == slice[j] ) {
						return false;
					}
				}
			}
			return true;
		}
		
	};

};